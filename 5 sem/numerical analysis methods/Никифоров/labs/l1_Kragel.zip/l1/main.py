from abc import ABC, abstractmethod

import numpy as np
from scipy.special import logsumexp
from scipy.stats import beta

from util import best_weights, distribute_equal_weight


class StepContext:
    def __init__(self, initial_visits, initial_conversions, max_weight):
        self.total_visits = initial_visits.copy()
        self.total_conversions = initial_conversions.copy()
        self.last_visits = None
        self.last_conversions = None
        self.time = 0
        self.max_weight = max_weight
        self.N = len(max_weight)
        self.equal_weights = distribute_equal_weight(max_weight)

    def step(self, visits, conversions):
        self.last_visits = visits
        self.last_conversions = conversions
        self.time += 1
        self.total_visits += visits
        self.total_conversions += conversions

    @property
    def total_cr(self):
        return self.total_conversions / np.clip(self.total_visits, 1, None)

    def select_best(self, scores=None):
        if scores is None:
            scores = self.total_cr
        return best_weights(self.max_weight, scores)


class BaseStrategy(ABC):
    @abstractmethod
    def step(self, ctx: StepContext):
        pas


class SoftmaxStrategy(BaseStrategy):
    def __init__(self, init_temp=10):
        self.init_temp = init_temp

    def step(self, ctx: StepContext):
        # temp = self.init_temp/self.time * np.log(self.time + 1)
        temp = self.init_temp / (ctx.time + 1) / 90

        def calc_w(r, budget, max_weight):
            logw = r - logsumexp(r)
            w = np.exp(logw) * budget
            overflow = w > max_weight
            if np.any(overflow):
                good = ~overflow
                budget_remain = budget - max_weight[overflow].sum()
                w[good] = calc_w(r[good], budget_remain, max_weight[good])
                w[overflow] = max_weight[overflow]
            return w

        rates = ctx.total_cr / temp
        result = calc_w(rates, 1, ctx.max_weight)
        return result
